import React, {Component} from 'react'
import Load from '../../util/load'
import { NODATA } from 'dns';
import electron from 'electron'
const fs = window.require('fs');
const path = window.require('path');

export default class Print extends Component {
    render() {
        return(
            <div>
                
            </div>    
        )
    }
}    
